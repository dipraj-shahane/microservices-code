package com.example.oauth2sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oauth2sampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(Oauth2sampleApplication.class, args);
	}

}
