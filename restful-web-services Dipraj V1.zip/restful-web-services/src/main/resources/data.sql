insert into user values (10001, sysdate(), 'Dipraj');
insert into user values (10002, sysdate(), 'Yuvraj');
insert into user values (10003, sysdate(), 'Sujata');
insert into user values (10004, sysdate(), 'Sample');

insert into post values (11001, 'My first post', 10001);
insert into post values (11002, 'My second post', 10001);
insert into post values (11003, 'Yuvraj first post', 10002);
insert into post values (11004, 'Yuvi second post', 10002);
insert into post values (11005, 'Dr. Sujata Wapte Govt. College, Nanded', 10003);
insert into post values (11006, 'Post for Sample User', 10004);
insert into post values (11007, 'One more post added by Dipraj', 10001);