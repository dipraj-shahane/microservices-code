package com.example.oauth2sample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oauth2sampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
